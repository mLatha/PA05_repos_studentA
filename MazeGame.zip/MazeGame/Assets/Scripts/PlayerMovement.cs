﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerMovement : MonoBehaviour
{

    public float speed;
   public Rigidbody playerRigidbody;

    int count;
    public Text UIText;
    float timer;
    public Text TimerText;

     void FixedUpdate()
    {
        
        float MoveHorizontal = Input.GetAxis("Horizontal");
        float MoveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(MoveHorizontal,0, MoveVertical);
        transform.Translate(movement * Time.deltaTime * speed);

    }

    private void Update()
    {
        UIText.text = "Number of coins collected : " + count;

        if(count>=6)
        {
            SceneManager.LoadScene("GameWin");

        }

        timer += Time.deltaTime;
        TimerText.text = "Timer : " + timer.ToString();


        if(timer >= 5f)
        {
            SceneManager.LoadScene("GameOver");
        }


    }

    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag == "Coin")
        {
            Destroy(collision.gameObject);
            count++;

            
        }

    }
}
